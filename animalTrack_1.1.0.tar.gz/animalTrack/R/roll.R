roll <-
function(y,z){
  roll = atan2(y,z)
  return(roll)  
}

